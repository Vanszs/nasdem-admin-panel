import { StructurePage } from '@/views/pages/structure/StructurePage';

export default function StructureDPD() {
  return <StructurePage />;
}

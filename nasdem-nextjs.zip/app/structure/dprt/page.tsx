import { StructurePage } from '@/views/pages/structure/StructurePage';

export default function StructureDPRT() {
  return <StructurePage />;
}

import LandingPageManagement from '@/views/pages/LandingPageManagement';

export default function LandingPage() {
  return <LandingPageManagement />;
}

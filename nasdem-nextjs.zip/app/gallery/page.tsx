import { GalleryPage } from '@/views/pages/gallery/GalleryPage';

export default function Gallery() {
  return <GalleryPage />;
}

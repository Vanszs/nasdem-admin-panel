import { NewsListPage } from '@/views/pages/news/NewsListPage';

export default function NewsPage() {
  return <NewsListPage />;
}

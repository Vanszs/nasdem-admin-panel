import { NewsFormPage } from '@/views/pages/news/NewsFormPage';

export default function NewsCreate() {
  return <NewsFormPage />;
}

import StatistikPemiluPage from '@/views/pages/StatistikPemiluPage';

export default function StatistikPemilu() {
  return <StatistikPemiluPage />;
}

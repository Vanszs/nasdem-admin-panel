import Index from '@/views/pages/Index';

export default function HomePage() {
  return <Index />;
}

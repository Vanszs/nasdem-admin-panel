import UserPage from '@/views/pages/UserPage';

export default function User() {
  return <UserPage />;
}

import { MemberListPage } from '@/views/pages/members/MemberListPage';

export default function Members() {
  return <MemberListPage />;
}
